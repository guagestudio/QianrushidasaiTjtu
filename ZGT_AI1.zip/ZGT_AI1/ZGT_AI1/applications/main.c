/*
 * Copyright (c) 2006-2025, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-04-13     RT-Thread    first version
 */

#include <rtthread.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
#include "main.h"
#include "fatfs.h"
#include "app_x-cube-ai.h"


#include "usart.h"
#include "lcd.h"
#include "sram.h"
#include "malloc.h"
#include "sdio.h"
#include "w25qxx.h"
#include "ff.h"

//#include "exfuns.h"
#include "fontupd.h"
#include "text.h"
#include "key.h"
#include "bt.h"

#include <string.h>


extern ADC_HandleTypeDef hadc3;
extern CRC_HandleTypeDef hcrc;
extern SD_HandleTypeDef hsd;
extern DMA_HandleTypeDef hdma_sdio_rx;
extern DMA_HandleTypeDef hdma_sdio_tx;
extern SPI_HandleTypeDef hspi1;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart6;
extern SRAM_HandleTypeDef hsram3;
extern SRAM_HandleTypeDef hsram4;

extern ai_handle network;
extern ai_u8 data_ins[];
extern ai_u8 data_outs[];

extern volatile uint16_t rxIndex;
extern volatile uint8_t dataReady;
volatile uint8_t pauseSending = 0;
extern uint8_t USART3_NewData;


#define USART1_printf(...) rt_kprintf(__VA_ARGS__)

int sram_test(void)
{
    uint32_t *p = (uint32_t *)0x68000000;
    for (int i = 0; i < 1024; i++) p[i] = i;
    for (int i = 0; i < 1024; i++) if (p[i] != i) return -1;
    return 0;
}
void test_utf8_to_unicode(void)
{
    uint8_t utf8_str[] = { 0xE4, 0xBD, 0xA0, 0xE5, 0xA5, 0xBD, 0 };
    uint16_t unicode;
    uint8_t len;
    uint8_t *ptr = utf8_str;

    USART1_printf("  UTF-8תUnicode:\n");

    while (*ptr)
    {
        len = UTF8_to_Unicode(ptr, &unicode);
        USART1_printf("UTF-8: 0x%X 0x%X 0x%X  Unicode: 0x%X \n",
                      ptr[0], ptr[1], ptr[2], unicode, len);
        ptr += len;
    }
}


static void user_main_thread(void *parameter)
{
    uint8_t key, t;
    uint8_t fontx[2];
    uint32_t fontcnt;


    MX_GPIO_Init();
    MX_DMA_Init();
    MX_USART3_UART_Init();
    MX_USART1_UART_Init();
    MX_FSMC_Init();
    MX_SDIO_SD_Init();
    MX_SPI1_Init();
    MX_ADC3_Init();
    MX_CRC_Init();
    MX_FATFS_Init();


    LCD_Init();
    LCD_Display_Dir(1);
    SRAM_Init();
    if (sram_test() != 0)
     {
         rt_kprintf("SRAM test failed! Check hardware connection!\n");
         while (1);
     }
     else
     {
         rt_kprintf("SRAM test passed.\n");
     }

    W25QXX_Init();
    my_mem_init(SRAMIN);
    my_mem_init(SRAMEX);
    MX_X_CUBE_AI_Init();
    static FATFS fatfs0;

    rt_kprintf("user_main_thread start!\\n");
    while (font_init())
    {
        LCD_Clear(WHITE);
        POINT_COLOR = RED;
        rt_thread_mdelay(1500);
        LCD_Clear(WHITE);
    }

    POINT_COLOR = RED;

    Show_Str(30, 50, 240, 24, "��ӭʹ�����﷭������", 24, 0);

    while (1)
    {
         if (pauseSending)
         {
             rt_thread_mdelay(1500);
             pauseSending = 0;
         }
         else
         {

            MX_X_CUBE_AI_Process();
        }
        rt_thread_mdelay(20);
    }
}


int rt_application_init(void)
{
    rt_kprintf("rt_application_init called!\\n");

    rt_thread_t tid = rt_thread_create("user_main",
                                       user_main_thread,
                                       RT_NULL,
                                       16384,
                                       10,
                                       10);
    if (tid != RT_NULL) {
        rt_kprintf("user_main_thread created!\\n");
        rt_kprintf("Thread object addr: 0x%08x\n", (unsigned int)tid);
        rt_kprintf("Thread stack addr: 0x%08x\n", (unsigned int)tid->stack_addr);
        rt_thread_startup(tid);
    } else {
        rt_kprintf("user_main_thread create failed!\\n");
    }
   // if (tid != RT_NULL)
   //     rt_thread_startup(tid);

    return 0;
}
INIT_APP_EXPORT(rt_application_init);
