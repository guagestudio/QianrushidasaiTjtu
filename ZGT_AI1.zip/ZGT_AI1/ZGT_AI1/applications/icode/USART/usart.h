/*
 * usart.h
 *
 *  Created on: 2025年1月14日
 *      Author: DELL
 */

#ifndef USART_USART_H_
#define USART_USART_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"  // 根据芯片型号替换为正确的 HAL 头文件
#include <stdint.h>         // 标准数据类型
#include <stdio.h>          // 支持 printf 重定向

// 定义 UART 缓冲区大小
#define USART_RX_BUFFER_SIZE 256
#define USART_TX_BUFFER_SIZE 256
#define RX_BUFFER_SIZE 8192  // 设置缓冲区大小
#define USART1_REC_LEN  200//定义USART1最大接收字节数
char rxBuffer[RX_BUFFER_SIZE];   // 接收缓冲区
char rxTemp[1];                 // 临时存储单个字节
typedef uint16_t WORD;
typedef uint8_t BYTE;
// 声明外部 UART 句柄（根据具体项目使用的 UART 替换 huart2 和 huart3）
extern UART_HandleTypeDef huart6;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart1;
#define USART_REC_LEN  200  // 定义接收缓存的长度
extern volatile uint8_t pauseSending;  // 用于控制是否暂停发送

extern uint8_t USART_RX_BUF[USART_REC_LEN];  // 接收缓冲区
extern uint16_t USART_RX_STA;               // 接收状态标志

#define USART3_REC_LEN  200//定义USART3最大接收字节数
extern uint8_t  USART3_RX_BUF[USART3_REC_LEN];//接收缓冲,最大USART_REC_LEN个字节.末字节为换行符
extern uint16_t USART3_RX_STA;//接收状态标记
extern uint8_t USART3_NewData;//当前串口中断接收的1个字节数据的缓存
// 函数声明
void USART_Init(void);                              // USART 初始化
void USART_SendString( const char *str); // 发送字符串
void USART_SendData(UART_HandleTypeDef *huart, uint8_t *data, uint16_t size); // 发送数据
void USART1_printf (char *fmt, ...);
void USART6_SendData(uint8_t data);
void USART6_SendString(uint8_t *data, uint8_t len);
void HAL_UART_RxCpltCallback1(UART_HandleTypeDef *huart);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void USART_ReceiveData(UART_HandleTypeDef *huart, uint8_t *buffer, uint16_t size);
void USART_ReceiveWithTimeout(UART_HandleTypeDef *huart, uint8_t *rxBuffer, uint16_t max_size);

uint8_t UTF8_to_Unicode(const uint8_t *src, uint16_t *unicode);
#ifdef __cplusplus
}
#endif



#endif /* USART_USART_H_ */
