/*
 * usart.c
 *
 *  Created on:
 *      Author: DELL
 */


#include "usart.h"
#include "main.h"
#include"lcd.h"
#include "fatfs.h"
#include <stdarg.h>
#include <string.h>
#include "text.h"

volatile uint16_t rxIndex = 0;
volatile uint8_t dataReady = 0;
uint8_t USART1_RX_BUF[USART1_REC_LEN];
uint16_t USART1_RX_STA=0;
uint8_t USART1_NewData;
//volatile uint8_t pauseSending = 0;
uint8_t USART3_RX_BUF[USART3_REC_LEN];
uint16_t USART3_RX_STA=0;
uint8_t USART3_NewData;

#ifdef __GNUC__
//int _write(int file, char *ptr, int len)
//{
 //   HAL_UART_Transmit(&huart1, (uint8_t *)ptr, len, HAL_MAX_DELAY);
 //   return len;
//}
#elif defined(__ICCARM__) || defined(__CC_ARM)
int fputc(int ch, FILE *f)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}
#endif

uint8_t UTF8_to_Unicode(const uint8_t *src, uint16_t *unicode) {
    if (!src || !unicode) return 0;

    uint8_t codeLen = 0;
    uint16_t result = 0;

    if ((src[0] & 0x80) == 0x00) {
        codeLen = 1;
        result = src[0];
    }
    else if ((src[0] & 0xE0) == 0xC0 && (src[1] & 0xC0) == 0x80) {
        codeLen = 2;
        result = ((src[0] & 0x1F) << 6) | (src[1] & 0x3F);
    }
    else if ((src[0] & 0xF0) == 0xE0 && (src[1] & 0xC0) == 0x80 && (src[2] & 0xC0) == 0x80) {
        codeLen = 3;
        result = ((src[0] & 0x0F) << 12) | ((src[1] & 0x3F) << 6) | (src[2] & 0x3F);
    }
    else if ((src[0] & 0xF8) == 0xF0 && (src[1] & 0xC0) == 0x80 &&
             (src[2] & 0xC0) == 0x80 && (src[3] & 0xC0) == 0x80) {
        codeLen = 4;
        result = ((src[0] & 0x07) << 18) | ((src[1] & 0x3F) << 12) |
                 ((src[2] & 0x3F) << 6) | (src[3] & 0x3F);
    }
    else {
        return 0;
    }

    *unicode = result;
    return codeLen;
}


void USART1_printf (char *fmt, ...){
    char buff[USART1_REC_LEN+1];
    uint16_t i=0;
    va_list arg_ptr;
    va_start(arg_ptr, fmt);
    vsnprintf(buff, USART1_REC_LEN+1, fmt,  arg_ptr);
    i=strlen(buff);
    if(strlen(buff)>USART1_REC_LEN)i=USART1_REC_LEN;
    HAL_UART_Transmit(&huart1,(uint8_t  *)buff,i,0xffff);
    va_end(arg_ptr);
}


void USART_SendString(const char *str) {
    HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), HAL_MAX_DELAY);
}

void USART_SendData(UART_HandleTypeDef *huart, uint8_t *data, uint16_t size)
{
    HAL_UART_Transmit(huart, data, size, HAL_MAX_DELAY);

}


void USART6_SendData(uint8_t data)
{
    while (HAL_UART_GetState(&huart6) != HAL_UART_STATE_READY);
    HAL_UART_Transmit(&huart6, &data, 1, HAL_MAX_DELAY);
}


void USART6_SendString(uint8_t *data, uint8_t len)
{
    for (uint8_t i = 0; i < len; i++) {
        USART6_SendData(data[i]);
    }
}



void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

    if (huart == &huart3)
    {
        static uint8_t rxBuffer[64] = {0};
        static uint8_t rxIndex = 0;


        if (USART3_NewData == '\n' || rxIndex >= sizeof(rxBuffer) - 1)
        {
            rxBuffer[rxIndex] = '\0';
            uint8_t gbkBuffer[64] = {0};
            uint8_t *utf8_ptr = rxBuffer;
            uint8_t *gbk_ptr = gbkBuffer;

            while (*utf8_ptr) {
                uint16_t unicode = 0;

                uint8_t len = UTF8_to_Unicode(utf8_ptr, &unicode);


                uint16_t gbk = unicode_to_gbk(unicode);
             if (gbk) {
                *gbk_ptr++ = gbk >> 8;
                *gbk_ptr++ = gbk & 0xFF;
                           }

                utf8_ptr += (*utf8_ptr & 0xE0) == 0xC0 ? 2 :
              (*utf8_ptr & 0xF0) == 0xE0 ? 3 :
                                       1;
                       }

            POINT_COLOR = BLUE;
            uint16_t screen_height = 320;
            uint16_t text_y = screen_height - 40;

            Show_Str(30, text_y, 200, 24, (char *)gbkBuffer, 24, 0);

            extern char display_buffer[128];
            memset(display_buffer, 0, sizeof(display_buffer));
            pauseSending = 1;
            rxIndex = 0;
        }
        else
        {
            rxBuffer[rxIndex++] = USART3_NewData;
        }

        HAL_UART_Receive_IT(&huart3, &USART3_NewData, 1);
    }
}



void USART_ReceiveData(UART_HandleTypeDef *huart, uint8_t *buffer, uint16_t size)
{
    HAL_UART_Receive(huart, buffer, size, HAL_MAX_DELAY);
}

