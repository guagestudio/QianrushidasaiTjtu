/*
 * w25qxx.h
 *
 *  Created on: Mar 2, 2025
 *      Author: DELL
 */

#ifndef W25QXX_W25QXX_H_
#define W25QXX_W25QXX_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdint.h>

/* Exported types ------------------------------------------------------------*/
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;

/* Exported constants --------------------------------------------------------*/
// W25Xϵ��/Qϵ��оƬ�б�
#define W25Q80    0xEF13
#define W25Q16    0xEF14
#define W25Q32    0xEF15
#define W25Q64    0xEF16
#define W25Q128   0xEF17
#define W25Q256   0xEF18

#define NM25Q80   0x5213
#define NM25Q16   0x5214
#define NM25Q32   0x5215
#define NM25Q64   0x5216
#define NM25Q128  0x5217
#define NM25Q256  0x5218

extern u16 W25QXX_TYPE;  // ����W25QXXоƬ�ͺ�

/* ������Ƭѡ�������ӵ�PB14������������ */
#define W25QXX_CS_GPIO_Port GPIOB
#define W25QXX_CS_Pin      GPIO_PIN_14
/* Exported macro ------------------------------------------------------------*/
/* ����W25QXX��Ƭѡ�źſ��ƺ꣬��ȷ����main.h���Ѷ���W25QXX_CS_GPIO_Port��W25QXX_CS_Pin */
#define W25QXX_CS_LOW()    HAL_GPIO_WritePin(W25QXX_CS_GPIO_Port, W25QXX_CS_Pin, GPIO_PIN_RESET)
#define W25QXX_CS_HIGH()   HAL_GPIO_WritePin(W25QXX_CS_GPIO_Port, W25QXX_CS_Pin, GPIO_PIN_SET)

/* ָ��� */
#define W25X_WriteEnable        0x06
#define W25X_WriteDisable       0x04
#define W25X_ReadStatusReg1     0x05
#define W25X_ReadStatusReg2     0x35
#define W25X_ReadStatusReg3     0x15
#define W25X_WriteStatusReg1    0x01
#define W25X_WriteStatusReg2    0x31
#define W25X_WriteStatusReg3    0x11
#define W25X_ReadData           0x03
#define W25X_FastReadData       0x0B
#define W25X_FastReadDual       0x3B
#define W25X_PageProgram        0x02
#define W25X_BlockErase         0xD8
#define W25X_SectorErase        0x20
#define W25X_ChipErase          0xC7
#define W25X_PowerDown          0xB9
#define W25X_ReleasePowerDown   0xAB
#define W25X_DeviceID           0xAB
#define W25X_ManufactDeviceID   0x90
#define W25X_JedecDeviceID      0x9F
#define W25X_Enable4ByteAddr    0xB7
#define W25X_Exit4ByteAddr      0xE9

/* Exported functions prototypes ---------------------------------------------*/
void W25QXX_Init(void);
u16  W25QXX_ReadID(void);               // ��ȡFLASH ID
u8   W25QXX_ReadSR(u8 regno);           // ��ȡ״̬�Ĵ���
void W25QXX_4ByteAddr_Enable(void);     // ʹ��4�ֽڵ�ַģʽ
void W25QXX_Write_SR(u8 regno, u8 sr);    // д״̬�Ĵ���
void W25QXX_Write_Enable(void);         // дʹ��
void W25QXX_Write_Disable(void);        // д����
void W25QXX_Write_NoCheck(u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite);
void W25QXX_Read(u8* pBuffer, u32 ReadAddr, u16 NumByteToRead);   // ��ȡflash
void W25QXX_Write(u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite);  // д��flash
void W25QXX_Erase_Chip(void);           // ��Ƭ����
void W25QXX_Erase_Sector(u32 Dst_Addr);   // ��������
void W25QXX_Wait_Busy(void);            // �ȴ�����
void W25QXX_PowerDown(void);            // �������ģʽ
void W25QXX_WAKEUP(void);               // ����

#ifdef __cplusplus
}
#endif

#endif /* W25QXX_W25QXX_H_ */
