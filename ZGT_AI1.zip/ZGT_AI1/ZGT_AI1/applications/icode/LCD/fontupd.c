/*
 * fontupd.c
 *
 *  Created on: 2025��3��3��
 *      Author: DELL
 */

#include "fontupd.h"
#include "ff.h"
#include "malloc.h"
#include "w25qxx.h"
#include "lcd.h"
#include "usart.h"

//�ֿ����ڴ����е�·��
#define FONTSECSIZE	 	791
//�ֿ�����ʼ��ַ
#define FONTINFOADDR 	1024*1024*12
_font_info ftinfo;
//uint8_t*const GBK24_PATH="/ziku/GBK24.FON";		//GBK24�Ĵ��λ��
//uint8_t*const GBK16_PATH="/ziku/GBK16.FON";		//GBK16�Ĵ��λ��
//uint8_t*const GBK12_PATH="/ziku/GBK12.FON";		//GBK12�Ĵ��λ��
//uint8_t*const UNIGBK_PATH="/ziku/UNIGBK.BIN";		//UNIGBK.BIN�Ĵ��λ��
uint8_t*const GBK24_PATH="D:/stm32cubeIDE_1.8.0/ziku/GBK24.FON";
uint8_t*const GBK16_PATH="D:/stm32cubeIDE_1.8.0/ziku/GBK16.FON";
uint8_t*const GBK12_PATH="D:/stm32cubeIDE_1.8.0/ziku/GBK12.FON";
uint8_t*const UNIGBK_PATH="D:/stm32cubeIDE_1.8.0/ziku/UNIGBK.BIN";
uint32_t fupd_prog(uint16_t x, uint16_t y, uint8_t size, uint32_t fsize, uint32_t pos)
{
    float prog;
    uint8_t t = 0xFF;
    prog = (float)pos / fsize;
    prog *= 100;
    if (t != prog)
    {
        LCD_ShowString(x + 3 * size / 2, y, 240, 320, size, "%");
        t = prog;
        if (t > 100) t = 100;
        LCD_ShowNum(x, y, t, 3, size);  // ��ʾ�ٷֱ�
    }
    return 0;
}

uint8_t updata_fontx(uint16_t x, uint16_t y, uint8_t size, uint8_t *fxpath, uint8_t fx)
{
    uint32_t flashaddr = 0;
    FIL *fftemp;
    uint8_t *tempbuf;
    uint8_t res;
    uint16_t bread;
    uint32_t offx = 0;
    uint8_t rval = 0;
    fftemp=(FIL*)mymalloc(SRAMIN,sizeof(FIL));
   // fftemp = (FIL*)malloc(sizeof(FIL));
    if (fftemp == NULL) rval = 1;
    tempbuf=mymalloc(SRAMIN,4096);// ����4KB������
    if (tempbuf == NULL) rval = 1;

    res = f_open(fftemp, (const TCHAR*)fxpath, FA_READ);
    if (res) rval = 2;

    if (rval == 0)
    {
        switch (fx)
        {
        case 0:
            ftinfo.ugbkaddr = FONTINFOADDR + sizeof(ftinfo);
            ftinfo.ugbksize = fftemp->obj.objsize;
            flashaddr = ftinfo.ugbkaddr;
            break;
        case 1:
            ftinfo.f12addr = ftinfo.ugbkaddr + ftinfo.ugbksize;
            ftinfo.gbk12size = fftemp->obj.objsize;
            flashaddr = ftinfo.f12addr;
            break;
        case 2:
            ftinfo.f16addr = ftinfo.f12addr + ftinfo.gbk12size;
            ftinfo.gbk16size = fftemp->obj.objsize;
            flashaddr = ftinfo.f16addr;
            break;
        case 3:
            ftinfo.f24addr = ftinfo.f16addr + ftinfo.gbk16size;
            ftinfo.gbk24size = fftemp->obj.objsize;
            flashaddr = ftinfo.f24addr;
            break;
        }

        while (res == FR_OK)
        {
            res = f_read(fftemp, tempbuf, 4096, (UINT*)&bread);
            if (res != FR_OK) break;
            W25QXX_Write(tempbuf, offx + flashaddr, 4096);
            offx += bread;
            fupd_prog(x, y, size, fftemp->obj.objsize, offx);
            if (bread != 4096) break;
        }

        f_close(fftemp);
    }

	myfree(SRAMIN,fftemp);	//�ͷ��ڴ�
	myfree(SRAMIN,tempbuf);	//�ͷ��ڴ�
	return res;
}

uint8_t update_font(uint16_t x, uint16_t y, uint8_t size, uint8_t *src)
{
    uint8_t *pname;
    uint32_t *buf;
    uint8_t res = 0;
    uint16_t i, j;
    FIL *fftemp;
    uint8_t rval = 0;

    res = 0xFF;
    ftinfo.fontok = 0xFF;
	pname=mymalloc(SRAMIN,100);
	buf=mymalloc(SRAMIN,4096);
	fftemp=(FIL*)mymalloc(SRAMIN,sizeof(FIL));
	if(buf==NULL||pname==NULL||fftemp==NULL)
	{
		myfree(SRAMIN,fftemp);
		myfree(SRAMIN,pname);
		myfree(SRAMIN,buf);
		return 5;
	}

    // �������ļ�����Ƿ����
    strcpy((char*)pname, (char*)src);
    strcat((char*)pname, (char*)UNIGBK_PATH);
    res = f_open(fftemp, (const TCHAR*)pname, FA_READ);
    if (res) rval |= 1 << 4;

    strcpy((char*)pname, (char*)src);
    strcat((char*)pname, (char*)GBK12_PATH);
    res = f_open(fftemp, (const TCHAR*)pname, FA_READ);
    if (res) rval |= 1 << 5;

    strcpy((char*)pname, (char*)src);
    strcat((char*)pname, (char*)GBK16_PATH);
    res = f_open(fftemp, (const TCHAR*)pname, FA_READ);
    if (res) rval |= 1 << 6;

    strcpy((char*)pname, (char*)src);
    strcat((char*)pname, (char*)GBK24_PATH);
    res = f_open(fftemp, (const TCHAR*)pname, FA_READ);
    if (res) rval |= 1 << 7;

    myfree(SRAMIN,fftemp);

    if (rval == 0)
    {
        LCD_ShowString(x, y, 240, 320, size, "Erasing sectors...");
        for (i = 0; i < FONTSECSIZE; i++)
        {
            fupd_prog(x + 20 * size / 2, y, size, FONTSECSIZE, i);
            W25QXX_Read((uint8_t*)buf, ((FONTINFOADDR / 4096) + i) * 4096, 4096);
            for (j = 0; j < 1024; j++)
            {
                if (buf[j] != 0xFFFFFFFF) break;
            }
            if (j != 1024) W25QXX_Erase_Sector((FONTINFOADDR / 4096) + i);
        }

        myfree(SRAMIN,buf);
        LCD_ShowString(x, y, 240, 320, size, "Updating UNIGBK.BIN");
        strcpy((char*)pname, (char*)src);
        strcat((char*)pname, (char*)UNIGBK_PATH);
        res = updata_fontx(x + 20 * size / 2, y, size, pname, 0);
        if(res){myfree(SRAMIN,pname);return 1;}

        LCD_ShowString(x, y, 240, 320, size, "Updating GBK12.BIN");
        strcpy((char*)pname, (char*)src);
        strcat((char*)pname, (char*)GBK12_PATH);
        res = updata_fontx(x + 20 * size / 2, y, size, pname, 1);
        if(res){myfree(SRAMIN,pname);return 2;}

        LCD_ShowString(x, y, 240, 320, size, "Updating GBK16.BIN");
        strcpy((char*)pname, (char*)src);
        strcat((char*)pname, (char*)GBK16_PATH);
        res = updata_fontx(x + 20 * size / 2, y, size, pname, 2);
        if(res){myfree(SRAMIN,pname);return 3;}

        LCD_ShowString(x, y, 240, 320, size, "Updating GBK24.BIN");
        strcpy((char*)pname, (char*)src);
        strcat((char*)pname, (char*)GBK24_PATH);
        res = updata_fontx(x + 20 * size / 2, y, size, pname, 3);
        if(res){myfree(SRAMIN,pname);return 4;}

        ftinfo.fontok = 0xAA;
        W25QXX_Write((uint8_t*)&ftinfo, FONTINFOADDR, sizeof(ftinfo));
    }

	myfree(SRAMIN,pname);
	myfree(SRAMIN,buf);
    return rval;
}

uint8_t font_init(void)
{
    uint8_t t = 0;
    W25QXX_Init();

    while (t < 10)
    {
        t++;
        W25QXX_Read((uint8_t*)&ftinfo, FONTINFOADDR, sizeof(ftinfo));
       // USART1_printf("Attempt %d: ftinfo.fontok = 0x%02X\r\n", t, ftinfo.fontok);
        if (ftinfo.fontok == 0xAA) break;
        HAL_Delay(20);
    }
    if (ftinfo.fontok != 0xAA)
    	{
    	//USART1_printf("Font Init Failed! ftinfo.fontok = 0x%02X\r\n", ftinfo.fontok);
    	return 1;
    	}
    return 0;
}


