/*
 * w25qxx.c
 *
 *  Created on: Mar 2, 2025
 *      Author: DELL
 */


/* Includes ------------------------------------------------------------------*/
#include "w25qxx.h"
#include "stm32f4xx_hal.h"
#include "spi.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#ifndef W25QXX_CS_LOW
#define W25QXX_CS_LOW()  HAL_GPIO_WritePin(W25QXX_CS_GPIO_Port, W25QXX_CS_Pin, GPIO_PIN_RESET)
#endif

#ifndef W25QXX_CS_HIGH
#define W25QXX_CS_HIGH() HAL_GPIO_WritePin(W25QXX_CS_GPIO_Port, W25QXX_CS_Pin, GPIO_PIN_SET)
#endif
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
extern SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
u16 W25QXX_TYPE = W25Q256;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
static uint8_t W25QXX_SPI_TransmitReceive(uint8_t txData);

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



static uint8_t W25QXX_SPI_TransmitReceive(uint8_t txData)
{
    uint8_t rxData;
    HAL_SPI_TransmitReceive(&hspi1, &txData, &rxData, 1, HAL_MAX_DELAY);
    return rxData;
}
/* USER CODE END 0 */

/* Exported functions --------------------------------------------------------*/

void W25QXX_Init(void)
{
    uint8_t temp;


    W25QXX_CS_HIGH();


    W25QXX_TYPE = W25QXX_ReadID();
   // USART1_printf("W25QXX Init: Flash ID = 0x%08X\r\n", W25QXX_TYPE);
    if(W25QXX_TYPE == W25Q256)
    {
        temp = W25QXX_ReadSR(3);
        if((temp & 0x01) == 0)
        {
            W25QXX_CS_LOW();
            W25QXX_SPI_TransmitReceive(W25X_Enable4ByteAddr);
            W25QXX_CS_HIGH();
        }
    }
    printf(" W25QXX READY\n");
    /* USER CODE BEGIN W25QXX_Init 2 */

    /* USER CODE END W25QXX_Init 2 */
}


uint8_t W25QXX_ReadSR(uint8_t regno)
{
    uint8_t byte = 0;
    uint8_t command = 0;

    switch(regno)
    {
        case 1:
            command = W25X_ReadStatusReg1;
            break;
        case 2:
            command = W25X_ReadStatusReg2;
            break;
        case 3:
            command = W25X_ReadStatusReg3;
            break;
        default:
            command = W25X_ReadStatusReg1;
            break;
    }

    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(command);
    byte = W25QXX_SPI_TransmitReceive(0xFF);
    W25QXX_CS_HIGH();
    return byte;
}


void W25QXX_Write_SR(uint8_t regno, uint8_t sr)
{
    uint8_t command = 0;

    switch(regno)
    {
        case 1:
            command = W25X_WriteStatusReg1;
            break;
        case 2:
            command = W25X_WriteStatusReg2;
            break;
        case 3:
            command = W25X_WriteStatusReg3;
            break;
        default:
            command = W25X_WriteStatusReg1;
            break;
    }

    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(command);
    W25QXX_SPI_TransmitReceive(sr);
    W25QXX_CS_HIGH();
}


void W25QXX_Write_Enable(void)
{
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_WriteEnable);
    W25QXX_CS_HIGH();
}


void W25QXX_Write_Disable(void)
{
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_WriteDisable);
    W25QXX_CS_HIGH();
}


uint16_t W25QXX_ReadID(void)
{
    uint16_t Temp = 0;
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(0x90);
    W25QXX_SPI_TransmitReceive(0x00);
    W25QXX_SPI_TransmitReceive(0x00);
    W25QXX_SPI_TransmitReceive(0x00);
    Temp |= (uint16_t)(W25QXX_SPI_TransmitReceive(0xFF)) << 8;
    Temp |= W25QXX_SPI_TransmitReceive(0xFF);
    W25QXX_CS_HIGH();
    return Temp;
}


void W25QXX_Read(uint8_t* pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
    uint16_t i;
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_ReadData);
    if(W25QXX_TYPE == W25Q256)
    {
        W25QXX_SPI_TransmitReceive((uint8_t)(ReadAddr >> 24));
    }
    W25QXX_SPI_TransmitReceive((uint8_t)(ReadAddr >> 16));
    W25QXX_SPI_TransmitReceive((uint8_t)(ReadAddr >> 8));
    W25QXX_SPI_TransmitReceive((uint8_t)ReadAddr);
    for(i = 0; i < NumByteToRead; i++)
    {
        pBuffer[i] = W25QXX_SPI_TransmitReceive(0xFF);
    }
    W25QXX_CS_HIGH();
}


void W25QXX_Write_Page(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
    uint16_t i;
    W25QXX_Write_Enable();
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_PageProgram);
    if(W25QXX_TYPE == W25Q256)
    {
        W25QXX_SPI_TransmitReceive((uint8_t)(WriteAddr >> 24));
    }
    W25QXX_SPI_TransmitReceive((uint8_t)(WriteAddr >> 16));
    W25QXX_SPI_TransmitReceive((uint8_t)(WriteAddr >> 8));
    W25QXX_SPI_TransmitReceive((uint8_t)WriteAddr);
    for(i = 0; i < NumByteToWrite; i++)
    {
        W25QXX_SPI_TransmitReceive(pBuffer[i]);
    }
    W25QXX_CS_HIGH();
    W25QXX_Wait_Busy();
}


void W25QXX_Write_NoCheck(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
    uint16_t pageremain;
    pageremain = 256 - (WriteAddr % 256);
    if(NumByteToWrite <= pageremain)
    {
        pageremain = NumByteToWrite;
    }
    while(1)
    {
        W25QXX_Write_Page(pBuffer, WriteAddr, pageremain);
        if(NumByteToWrite == pageremain)
        {
            break;
        }
        else
        {
            pBuffer    += pageremain;
            WriteAddr  += pageremain;
            NumByteToWrite -= pageremain;
            if(NumByteToWrite > 256)
            {
                pageremain = 256;
            }
            else
            {
                pageremain = NumByteToWrite;
            }
        }
    }
}


uint8_t W25QXX_BUFFER[4096];


void W25QXX_Write(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
    uint32_t secpos;
    uint16_t secoff;
    uint16_t secremain;
    uint16_t i;
    uint8_t* W25QXX_BUF = W25QXX_BUFFER;

    secpos   = WriteAddr / 4096;
    secoff   = WriteAddr % 4096;
    secremain= 4096 - secoff;

    if(NumByteToWrite <= secremain)
    {
        secremain = NumByteToWrite;
    }

    while(1)
    {
        W25QXX_Read(W25QXX_BUF, secpos * 4096, 4096);
        for(i = 0; i < secremain; i++)
        {
            if(W25QXX_BUF[secoff + i] != 0xFF)
            {
                break;
            }
        }
        if(i < secremain)
        {
            W25QXX_Erase_Sector(secpos);
            for(i = 0; i < secremain; i++)
            {
                W25QXX_BUF[i + secoff] = pBuffer[i];
            }
            W25QXX_Write_NoCheck(W25QXX_BUF, secpos * 4096, 4096);
        }
        else
        {
            W25QXX_Write_NoCheck(pBuffer, WriteAddr, secremain);
        }

        if(NumByteToWrite == secremain)
        {
            break;
        }
        else
        {
            secpos++;
            secoff = 0;
            pBuffer    += secremain;
            WriteAddr  += secremain;
            NumByteToWrite -= secremain;
            if(NumByteToWrite > 4096)
            {
                secremain = 4096;
            }
            else
            {
                secremain = NumByteToWrite;
            }
        }
    }
}


void W25QXX_Erase_Chip(void)
{
    W25QXX_Write_Enable();
    W25QXX_Wait_Busy();
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_ChipErase);
    W25QXX_CS_HIGH();
    W25QXX_Wait_Busy();
}


void W25QXX_Erase_Sector(uint32_t Dst_Addr)
{
    Dst_Addr *= 4096;
    W25QXX_Write_Enable();
    W25QXX_Wait_Busy();
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_SectorErase);
    if(W25QXX_TYPE == W25Q256)
    {
        W25QXX_SPI_TransmitReceive((uint8_t)(Dst_Addr >> 24));
    }
    W25QXX_SPI_TransmitReceive((uint8_t)(Dst_Addr >> 16));
    W25QXX_SPI_TransmitReceive((uint8_t)(Dst_Addr >> 8));
    W25QXX_SPI_TransmitReceive((uint8_t)Dst_Addr);
    W25QXX_CS_HIGH();
    W25QXX_Wait_Busy();
}


void W25QXX_Wait_Busy(void)
{
    while((W25QXX_ReadSR(1) & 0x01) == 0x01);
}


void W25QXX_PowerDown(void)
{
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_PowerDown);
    W25QXX_CS_HIGH();

    HAL_Delay(1);
}


void W25QXX_WAKEUP(void)
{
    W25QXX_CS_LOW();
    W25QXX_SPI_TransmitReceive(W25X_ReleasePowerDown);
    W25QXX_CS_HIGH();

    HAL_Delay(1);
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

