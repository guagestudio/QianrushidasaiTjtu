/*
 * spi.h
 *
 *  Created on: Mar 2, 2025
 *      Author: DELL
 */

#ifndef SPI_SPI_H_
#define SPI_SPI_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include "stm32f4xx_hal.h"

extern SPI_HandleTypeDef hspi1;  // SPI1�������CubeMX����

void MX_SPI1_Init(void);  // CubeMX���ɵĳ�ʼ������
void SPI1_SetSpeed(uint8_t SPI_BaudRatePrescaler);
uint8_t SPI1_ReadWriteByte(uint8_t TxData);

#ifdef __cplusplus
}
#endif



#endif /* SPI_SPI_H_ */
