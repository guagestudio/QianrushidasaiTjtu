
/**
  ******************************************************************************
  * @file    app_x-cube-ai.c
  * @author  X-CUBE-AI C code generator
  * @brief   AI program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

 /*
  * Description
  *   v1.0 - Minimum template to show how to use the Embedded Client API
  *          model. Only one input and one output is supported. All
  *          memory resources are allocated statically (AI_NETWORK_XX, defines
  *          are used).
  *          Re-target of the printf function is out-of-scope.
  *   v2.0 - add multiple IO and/or multiple heap support
  *
  *   For more information, see the embeded documentation:
  *
  *       [1] %X_CUBE_AI_DIR%/Documentation/index.html
  *
  *   X_CUBE_AI_DIR indicates the location where the X-CUBE-AI pack is installed
  *   typical : C:\Users\<user_name>\STM32Cube\Repository\STMicroelectronics\X-CUBE-AI\7.1.0
  */

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#if defined ( __ICCARM__ )
#elif defined ( __CC_ARM ) || ( __GNUC__ )
#endif

/* System headers */
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
#include <string.h>

#include "app_x-cube-ai.h"
#include "main.h"
#include "ai_datatypes_defines.h"
#include "aizgt6.h"
#include "aizgt6_data.h"

/* USER CODE BEGIN includes */
#include "usart.h"
#include "lcd.h"
extern ADC_HandleTypeDef hadc3;
UART_HandleTypeDef huart1;

UART_HandleTypeDef huart3;
#define ADC_CHANNELS 5
#define ADC_MAX_VALUE 3309.0f
#define NUM_CLASSES 28
static int ai_process_state = 0;
char display_buffer[128] = {0};
/* USER CODE END includes */

/* IO buffers ----------------------------------------------------------------*/

#if !defined(AI_AIZGT6_INPUTS_IN_ACTIVATIONS)
AI_ALIGNED(4) ai_i8 data_in_1[AI_AIZGT6_IN_1_SIZE_BYTES];
ai_i8* data_ins[AI_AIZGT6_IN_NUM] = {
data_in_1
};
#else
ai_i8* data_ins[AI_AIZGT6_IN_NUM] = {
NULL
};
#endif

#if !defined(AI_AIZGT6_OUTPUTS_IN_ACTIVATIONS)
AI_ALIGNED(4) ai_i8 data_out_1[AI_AIZGT6_OUT_1_SIZE_BYTES];
ai_i8* data_outs[AI_AIZGT6_OUT_NUM] = {
data_out_1
};
#else
ai_i8* data_outs[AI_AIZGT6_OUT_NUM] = {
NULL
};
#endif

/* Activations buffers -------------------------------------------------------*/

AI_ALIGNED(32)
static uint8_t pool0[AI_AIZGT6_DATA_ACTIVATION_1_SIZE];

ai_handle data_activations0[] = {pool0};

/* AI objects ----------------------------------------------------------------*/

static ai_handle aizgt6 = AI_HANDLE_NULL;

static ai_buffer* ai_input;
static ai_buffer* ai_output;

static void ai_log_err(const ai_error err, const char *fct)
{
  /* USER CODE BEGIN log */
  if (fct)
    printf("TEMPLATE - Error (%s) - type=0x%02x code=0x%02x\r\n", fct,
        err.type, err.code);
  else
    printf("TEMPLATE - Error - type=0x%02x code=0x%02x\r\n", err.type, err.code);

  do {} while (1);
  /* USER CODE END log */
}

static int ai_boostrap(ai_handle *act_addr)
{
  ai_error err;

  /* Create and initialize an instance of the model */
  err = ai_aizgt6_create_and_init(&aizgt6, act_addr, NULL);
  if (err.type != AI_ERROR_NONE) {
    ai_log_err(err, "ai_aizgt6_create_and_init");
    return -1;
  }

  ai_input = ai_aizgt6_inputs_get(aizgt6, NULL);
  ai_output = ai_aizgt6_outputs_get(aizgt6, NULL);

#if defined(AI_AIZGT6_INPUTS_IN_ACTIVATIONS)
  /*  In the case where "--allocate-inputs" option is used, memory buffer can be
   *  used from the activations buffer. This is not mandatory.
   */
  for (int idx=0; idx < AI_AIZGT6_IN_NUM; idx++) {
	data_ins[idx] = ai_input[idx].data;
  }
#else
  for (int idx=0; idx < AI_AIZGT6_IN_NUM; idx++) {
	  ai_input[idx].data = data_ins[idx];
  }
#endif

#if defined(AI_AIZGT6_OUTPUTS_IN_ACTIVATIONS)
  /*  In the case where "--allocate-outputs" option is used, memory buffer can be
   *  used from the activations buffer. This is no mandatory.
   */
  for (int idx=0; idx < AI_AIZGT6_OUT_NUM; idx++) {
	data_outs[idx] = ai_output[idx].data;
  }
#else
  for (int idx=0; idx < AI_AIZGT6_OUT_NUM; idx++) {
	ai_output[idx].data = data_outs[idx];
  }
#endif

  return 0;
}

static int ai_run(void)
{
  ai_i32 batch;

  batch = ai_aizgt6_run(aizgt6, ai_input, ai_output);
  if (batch != 1) {
    ai_log_err(ai_aizgt6_get_error(aizgt6),
        "ai_aizgt6_run");
    return -1;
  }

  return 0;
}

/* USER CODE BEGIN 2 */
int acquire_and_process_data(ai_i8* data[])
{


    uint16_t ADC_BUF[5] = {0};
    float normalized_values[5] = {0};
    HAL_ADC_Start(&hadc3);

    if (HAL_ADC_PollForConversion(&hadc3, 10) == HAL_OK)
    {

        ADC_BUF[0] = HAL_ADC_GetValue(&hadc3);


        HAL_ADC_Start(&hadc3);
        if (HAL_ADC_PollForConversion(&hadc3, 10) == HAL_OK)
        {

            ADC_BUF[1] = HAL_ADC_GetValue(&hadc3);
        }

        HAL_ADC_Start(&hadc3);
        if (HAL_ADC_PollForConversion(&hadc3, 10) == HAL_OK)
        {

            ADC_BUF[2] = HAL_ADC_GetValue(&hadc3);
        }

        HAL_ADC_Start(&hadc3);
        if (HAL_ADC_PollForConversion(&hadc3, 10) == HAL_OK)
        {

            ADC_BUF[3] = HAL_ADC_GetValue(&hadc3);
        }

        HAL_ADC_Start(&hadc3);
        if (HAL_ADC_PollForConversion(&hadc3, 10) == HAL_OK)
        {

            ADC_BUF[4] = HAL_ADC_GetValue(&hadc3);
        }
      //  HAL_UART_Transmit(&huart3, (uint8_t *)result, strlen(result), HAL_MAX_DELAY);
    }

   printf(ADC_BUF[0],ADC_BUF[1],ADC_BUF[2],ADC_BUF[3],ADC_BUF[4]);

    if (HAL_ADC_Stop(&hadc3) != HAL_OK) {
        printf("ADC stop failed!\n");
        return -1;
    }


    for (int i = 0; i < 5; i++) {
        normalized_values[i] = (float)ADC_BUF[i] / ADC_MAX_VALUE;
    }
        memcpy(data[0], &normalized_values, sizeof(normalized_values));

  return 0;
}

int post_process(ai_i8* data[])
{

           static int backspace_count = 0;
       float* output = (float*)data[0];
           int predicted_label = 0;
           float max_confidence = output[0];
           static int first_letter_shown = 0;


           for (int i = 1; i < NUM_CLASSES; i++) {
               if (output[i] > max_confidence) {
                   max_confidence = output[i];
                   predicted_label = i;
               }
           }

           char result[128];
           if (max_confidence >= 0.8) {
                   if (predicted_label < 26) {
                        if (!first_letter_shown) {
                           LCD_Clear(WHITE);
                           first_letter_shown = 1;
                                   }
                        char predicted_char = 'a' + predicted_label;
                        int len = strlen(display_buffer);
                        if (len < sizeof(display_buffer) - 2) {
                        display_buffer[len] = predicted_char;
                        display_buffer[len + 1] = '\0';
                      // char predicted_char = 'a' + predicted_label;
                       sprintf(result, "%c\n", predicted_char);
                      // sprintf(oled_display, "Char: %c", predicted_char);  ��
                       Show_Str(30, 200, 200, 24, display_buffer, 24, 0);
                       backspace_count = 0;
                        }
                   } else if (predicted_label == 26) {
                       sprintf(result, "relax\r\n");
                      // sprintf(oled_display, "Relax");


                   } else if (predicted_label == 27) {
                       sprintf(result, "backspace\r\n");
                       backspace_count++;
                       if (backspace_count == 3) {
                          LCD_Clear(WHITE);
                          memset(display_buffer, 0, sizeof(display_buffer));
                          backspace_count = 0;
                          first_letter_shown = 0;
                                   }


              }
                   else {
                       sprintf(result, "Confidence too low\r\n");
                       //sprintf(oled_display, "Low Conf.");
                   }


          HAL_UART_Transmit(&huart3, (uint8_t *)result, strlen(result), HAL_MAX_DELAY);
          HAL_Delay(2000);

                   return 0;
                   }

}
/* USER CODE END 2 */

/* Entry points --------------------------------------------------------------*/

void MX_X_CUBE_AI_Init(void)
{
    /* USER CODE BEGIN 5 */
  printf("\r\nTEMPLATE - initialization\r\n");

  ai_boostrap(data_activations0);
    /* USER CODE END 5 */
}

void MX_X_CUBE_AI_Process(void)
{
    /* USER CODE BEGIN 6 */

  int res = 0;

              switch (ai_process_state) {
                  case 0:
                      res = acquire_and_process_data(data_ins);
                      if (res == 0) {
                          ai_process_state = 1;
                      } else {
                          ai_error err = {AI_ERROR_INVALID_STATE, AI_ERROR_CODE_NETWORK};
                          ai_log_err(err, "Acquire and process data FAILED");
                      }
                      break;

                  case 1:
                      res = ai_run();
                      if (res == 0) {
                          ai_process_state = 2;
                      } else {
                          ai_error err = {AI_ERROR_INVALID_STATE, AI_ERROR_CODE_NETWORK};
                          ai_log_err(err, "Neural network inference FAILED");
                      }
                      break;

                  case 2:
                      res = post_process(data_outs);
                      if (res == 0) {
                          ai_process_state = 0;
                      } else {
                          ai_error err = {AI_ERROR_INVALID_STATE, AI_ERROR_CODE_NETWORK};
                          ai_log_err(err, "Post process FAILED");
                      }
                      break;

                  default:
                      ai_process_state = 0;
                      break;
              }

    /* USER CODE END 6 */
}
#ifdef __cplusplus
}
#endif
