/**
  ******************************************************************************
  * @file    aizgt6_data_params.h
  * @author  AST Embedded Analytics Research Platform
  * @date    Tue Apr 22 23:51:39 2025
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#ifndef AIZGT6_DATA_PARAMS_H
#define AIZGT6_DATA_PARAMS_H
#pragma once

#include "ai_platform.h"

/*
#define AI_AIZGT6_DATA_WEIGHTS_PARAMS \
  (AI_HANDLE_PTR(&ai_aizgt6_data_weights_params[1]))
*/

#define AI_AIZGT6_DATA_CONFIG               (NULL)


#define AI_AIZGT6_DATA_ACTIVATIONS_SIZES \
  { 512, }
#define AI_AIZGT6_DATA_ACTIVATIONS_SIZE     (512)
#define AI_AIZGT6_DATA_ACTIVATIONS_COUNT    (1)
#define AI_AIZGT6_DATA_ACTIVATION_1_SIZE    (512)



#define AI_AIZGT6_DATA_WEIGHTS_SIZES \
  { 25456, }
#define AI_AIZGT6_DATA_WEIGHTS_SIZE         (25456)
#define AI_AIZGT6_DATA_WEIGHTS_COUNT        (1)
#define AI_AIZGT6_DATA_WEIGHT_1_SIZE        (25456)



#define AI_AIZGT6_DATA_ACTIVATIONS_TABLE_GET() \
  (&g_aizgt6_activations_table[1])

extern ai_handle g_aizgt6_activations_table[1 + 2];



#define AI_AIZGT6_DATA_WEIGHTS_TABLE_GET() \
  (&g_aizgt6_weights_table[1])

extern ai_handle g_aizgt6_weights_table[1 + 2];


#endif    /* AIZGT6_DATA_PARAMS_H */
